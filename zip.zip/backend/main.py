"""
Step 4 — FastAPI backend. This is the "Risk Prediction Engine" +
"Output & Alerts" stages from the architecture slide, wired together.

Design choice worth being able to explain to a judge: the endpoint
accepts an `entry_account` that already exists in the seed graph
(anchoring which mule chain this complaint belongs to), plus an
optional `new_hop` representing a fresh incoming transaction — this
is exactly what the Razorpay-webhook demo trigger will call: "a new
complaint just came in, attach it to this pre-seeded entry account
and predict from there."

Run it:
    uvicorn backend.main:app --reload --port 8000

Test it:
    curl -X POST http://localhost:8000/predict \
      -H "Content-Type: application/json" \
      -d '{"entry_account": "MULE_A3", "new_hop": {"amount": 190000, "minutes_ago": 5}}'
"""
import os
import sys
import pickle
import time
import math
from datetime import datetime, timedelta
from typing import Optional

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import networkx as nx
import xgboost as xgb
import shap
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from data.atms import ATMS, BRANCHES
from model.scoring import mule_score, burst_score, hub_score, geo_score

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FEATURES = ["mule_score", "burst_score", "geo_score", "hub_score"]
BRANCH_LOOKUP = {b["ifsc"]: b for b in BRANCHES}
ATM_LOOKUP = {a["id"]: a for a in ATMS}

app = FastAPI(title="T.R.A.C.E. — Risk Prediction API")

# ---------------------------------------------------------------------
# Load the seed graph and trained model ONCE at startup
# ---------------------------------------------------------------------
with open(os.path.join(BASE_DIR, "data", "seed_graph.pkl"), "rb") as f:
    SEED_GRAPH: nx.DiGraph = pickle.load(f)

MODEL = xgb.XGBClassifier()
MODEL.load_model(os.path.join(BASE_DIR, "model", "saved_risk_model.json"))
EXPLAINER = shap.TreeExplainer(MODEL)

# In-memory alert history, seeded with a plausible starting pattern so
# hub_score isn't flat-zero on the very first demo run. Grows in real
# time as /predict fires — each top-ranked ATM gets appended, so a
# repeated demo naturally shows hub_score rising for reused ATMs,
# exactly mirroring the real "recency-weighted centrality" behavior.
ALERT_HISTORY: list[dict] = [
    {"atm_id": "ATM001", "timestamp": datetime.now() - timedelta(hours=2)},
    {"atm_id": "ATM005", "timestamp": datetime.now() - timedelta(hours=5)},
    {"atm_id": "ATM005", "timestamp": datetime.now() - timedelta(days=1)},
    {"atm_id": "ATM010", "timestamp": datetime.now() - timedelta(hours=8)},
]


# ---------------------------------------------------------------------
# Request / response schemas
# ---------------------------------------------------------------------
class NewHop(BaseModel):
    amount: int
    minutes_ago: int = 2  # how long ago this incoming transfer landed — small = urgent


class ComplaintInput(BaseModel):
    entry_account: str          # must already exist in the seed graph
    new_hop: Optional[NewHop] = None
    complaint_text: Optional[str] = None


class RankedPrediction(BaseModel):
    atm_id: str
    atm_name: str
    confidence: float
    top_reasons: list[str]


class PredictResponse(BaseModel):
    entry_account: str
    mule_score: float
    burst_score: float
    predictions: list[RankedPrediction]


# ---------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------
def get_history_with_minutes_ago() -> list[dict]:
    """Convert stored real timestamps into minutes_ago at query time —
    keeps hub_score correct no matter how long the server's been up."""
    now = datetime.now()
    return [
        {"atm_id": h["atm_id"], "minutes_ago": (now - h["timestamp"]).total_seconds() / 60.0}
        for h in ALERT_HISTORY
    ]


def readable_reason(feature: str, value: float, contribution: float) -> str:
    labels = {
        "mule_score": "mule-chain relationship strength",
        "burst_score": "transaction burst / urgency",
        "geo_score": "geographic proximity",
        "hub_score": "historical cash-out reuse at this ATM",
    }
    direction = "raised" if contribution >= 0 else "lowered"
    return f"{labels[feature]} ({value:.2f}) {direction} the score by {abs(contribution):.2f}"


# ---------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------
@app.get("/health")
def health():
    return {"status": "ok", "atms_loaded": len(ATMS), "graph_nodes": SEED_GRAPH.number_of_nodes()}


@app.post("/predict", response_model=PredictResponse)
def predict(complaint: ComplaintInput):
    if complaint.entry_account not in SEED_GRAPH.nodes:
        raise HTTPException(
            status_code=404,
            detail=f"'{complaint.entry_account}' not found in graph. "
                    f"Known accounts include: {list(SEED_GRAPH.nodes)[:8]}...",
        )

    # Work on a COPY so a live demo run never mutates the shared seed graph
    G = SEED_GRAPH.copy()

    if complaint.new_hop:
        fresh_node = f"COMPLAINT_{int(time.time() * 1000)}"
        G.add_edge(
            fresh_node,
            complaint.entry_account,
            amount=complaint.new_hop.amount,
            minutes_ago=complaint.new_hop.minutes_ago,
        )

    m_score = mule_score(G, complaint.entry_account)
    b_score = burst_score(G, complaint.entry_account)
    home_ifsc = G.nodes[complaint.entry_account].get("home_ifsc")
    if home_ifsc is None:
        raise HTTPException(status_code=400, detail=f"'{complaint.entry_account}' has no home_ifsc set")
    branch = BRANCH_LOOKUP[home_ifsc]

    history = get_history_with_minutes_ago()

    rows = []
    for atm in ATMS:
        g_score = geo_score(branch["lat"], branch["lon"], atm["lat"], atm["lon"])
        h_score = hub_score(atm["id"], history)
        rows.append({
            "atm_id": atm["id"],
            "atm_name": atm["name"],
            "mule_score": m_score,
            "burst_score": b_score,
            "geo_score": g_score,
            "hub_score": h_score,
        })

    import pandas as pd
    feat_df = pd.DataFrame(rows)[FEATURES]
    probs = MODEL.predict_proba(feat_df)[:, 1]
    shap_values = EXPLAINER.shap_values(feat_df)

    for i, row in enumerate(rows):
        row["confidence"] = float(probs[i])
        row["shap"] = dict(zip(FEATURES, shap_values[i]))

    ranked = sorted(rows, key=lambda r: r["confidence"], reverse=True)[:3]

    predictions = []
    for r in ranked:
        contribs = sorted(r["shap"].items(), key=lambda kv: abs(kv[1]), reverse=True)
        reasons = [readable_reason(feat, r[feat], val) for feat, val in contribs[:2]]
        predictions.append(RankedPrediction(
            atm_id=r["atm_id"],
            atm_name=r["atm_name"],
            confidence=round(r["confidence"], 4),
            top_reasons=reasons,
        ))

    # record the top prediction into alert history — future calls will
    # see this ATM's hub_score rise, mirroring real reuse tracking
    if predictions:
        ALERT_HISTORY.append({"atm_id": predictions[0].atm_id, "timestamp": datetime.now()})

    return PredictResponse(
        entry_account=complaint.entry_account,
        mule_score=round(m_score, 4),
        burst_score=round(b_score, 4),
        predictions=predictions,
    )
