# T.R.A.C.E. — Prototype (Steps 1, 2 & 3 complete)

## What's built and verified so far

| File | What it does | Status |
|---|---|---|
| `data/atms.py` | 12 real Chennai ATM coords + 5 branch coords | Working |
| `data/build_graph.py` | Seed account graph: 3 mule chains + noise accounts | Working |
| `model/scoring.py` | `mule_score`, `burst_score`, `hub_score`, `geo_score` | Working, tested |
| `model/generate_training_data.py` | 300 synthetic cases x 12 ATMs = 3,600 labeled rows | Working |
| `model/train_risk_model.py` | XGBoost combiner + SHAP explanations | Working, tested |

## How to run it, in order

```bash
python3 -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install networkx xgboost shap pandas scikit-learn

PYTHONPATH=. python data/build_graph.py            # builds seed_graph.pkl
PYTHONPATH=. python model/scoring.py               # sanity-checks the 4 scores
PYTHONPATH=. python model/generate_training_data.py  # builds training_data.csv
PYTHONPATH=. python model/train_risk_model.py       # trains + evaluates + SHAP
```

## Verified results (from the last run)

```
Train: 225 cases  |  Test: 75 cases   (chronological split — train on
                                         earlier cases, test on later ones)

Precision@1 (hit-rate): 30.7%
Precision@3 (hit-rate): 69.3%
```

**Say this exact framing to judges:** "69.3% precision@3 on held-out
synthetic test cases — the true cash-out ATM was in our top-3 ranked
predictions about 7 times out of 10." Never call this "accuracy" —
it's validated on synthetic data only (see `model/generate_training_data.py`
docstring for why PaySim/kaggle.com couldn't be pulled directly in
this environment, and how to swap in real PaySim stats later).

SHAP explanations are real and working — example output:
```
#1  ATM005  risk_score=0.513  <-- TRUE ATM
     geo_score    contributed +2.447  (value=0.830)
     hub_score    contributed +0.064  (value=1.000)
     mule_score   contributed -0.013  (value=0.214)
     burst_score  contributed -0.000  (value=0.339)
```
This exact structure (ATM, risk_score, ranked feature contributions)
is what the dashboard's "top reasons" panel should render — the
frontend just needs to call the model and format this output, no
new logic needed there.

## Files produced by running the pipeline (not committed, regenerate as needed)
- `data/seed_graph.pkl` — pickled NetworkX graph
- `model/training_data.csv` — 3,600 labeled training rows
- `model/saved_risk_model.json` — trained XGBoost model, loadable via `xgb.XGBClassifier().load_model(...)`

## Next steps (not yet built)

1. **`backend/main.py`** — FastAPI `/predict` endpoint. Loads
   `saved_risk_model.json`, takes a complaint (account chain), computes
   the 4 scores against all 12 ATMs using `model/scoring.py`, runs
   `model.predict_proba`, ranks top-3, attaches SHAP explanation per
   ATM — this is mostly plumbing, all the hard logic already exists
   and is tested above.
2. **SQLite** for alerts/complaints (zero-ops, no server to manage
   during the demo — see earlier discussion).
3. Razorpay webhook (via ngrok) as the live-demo trigger, wired to
   call `/predict`.
4. Dashboard notification panel + Leaflet map, rendering exactly the
   SHAP output structure shown above.
5. SHA-256 audit log (quick, ~30 min once alerts exist).

## Team split from here

- **Person C** starts Step 4 (FastAPI `/predict`) now — everything it
  needs (`scoring.py`, `saved_risk_model.json`) already exists and is
  tested.
- **Person D** can start the dashboard UI immediately against the
  exact SHAP output shape shown above (fake it with a static JSON
  file matching that structure), then swap in the real `/predict`
  call once C's endpoint is up — nobody has to wait.
- **Person C** also owns Step 5 (Razorpay + ngrok) right after the
  endpoint works — do this early, it's the highest-risk external
  dependency.
