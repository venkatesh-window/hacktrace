"""
Step 1a — Seed ATM/branch location data.

Real Chennai ATM/branch coordinates, hand-picked from public map data.
In production this comes from the OpenStreetMap Overpass API
(amenity=atm / amenity=bank) — for the prototype we hardcode a
representative set so the geo-decay layer has real, meaningful
coordinates to work with.
"""

ATMS = [
    {"id": "ATM001", "name": "SBI ATM, T Nagar",              "lat": 13.0418, "lon": 80.2341},
    {"id": "ATM002", "name": "Canara Bank, Anna Nagar",        "lat": 13.0850, "lon": 80.2101},
    {"id": "ATM003", "name": "HDFC ATM, Velachery",            "lat": 12.9791, "lon": 80.2212},
    {"id": "ATM004", "name": "ICICI ATM, Adyar",               "lat": 13.0012, "lon": 80.2565},
    {"id": "ATM005", "name": "Indian Bank, Mylapore",          "lat": 13.0339, "lon": 80.2619},
    {"id": "ATM006", "name": "Axis Bank ATM, Nungambakkam",    "lat": 13.0603, "lon": 80.2417},
    {"id": "ATM007", "name": "SBI ATM, Guindy",                "lat": 13.0067, "lon": 80.2206},
    {"id": "ATM008", "name": "PNB ATM, Porur",                 "lat": 13.0381, "lon": 80.1564},
    {"id": "ATM009", "name": "Bank of Baroda, Tambaram",       "lat": 12.9249, "lon": 80.1000},
    {"id": "ATM010", "name": "Canara Bank, Perambur",          "lat": 13.1141, "lon": 80.2320},
    {"id": "ATM011", "name": "HDFC ATM, Chromepet",            "lat": 12.9516, "lon": 80.1462},
    {"id": "ATM012", "name": "ICICI ATM, Ambattur",            "lat": 13.1143, "lon": 80.1548},
]

# One branch coordinate per synthetic account "home IFSC" — this is
# what the mule account's location actually anchors to (see
# graph.py). Kept deliberately small: 5-6 branches is enough to
# demonstrate the geo layer without needing real IFSC data.
BRANCHES = [
    {"ifsc": "SBIN0001",  "name": "SBI, T Nagar branch",       "lat": 13.0400, "lon": 80.2350},
    {"ifsc": "CNRB0002",  "name": "Canara Bank, Anna Nagar",   "lat": 13.0860, "lon": 80.2110},
    {"ifsc": "HDFC0003",  "name": "HDFC, Velachery branch",    "lat": 12.9800, "lon": 80.2200},
    {"ifsc": "ICIC0004",  "name": "ICICI, Adyar branch",       "lat": 13.0020, "lon": 80.2570},
    {"ifsc": "AXIS0005",  "name": "Axis Bank, Nungambakkam",   "lat": 13.0610, "lon": 80.2420},
]

if __name__ == "__main__":
    print(f"{len(ATMS)} ATMs, {len(BRANCHES)} branches loaded")
    for a in ATMS[:3]:
        print(" ", a)
